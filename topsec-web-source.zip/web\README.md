# TOPSEC Survey Workspace (bản web)

Web app nội bộ cho công tác đo RTK/trắc địa: quản lý công trình theo hệ tọa độ VN-2000, nhập – sửa – xuất điểm,
bản đồ vệ tinh có cụm điểm, và bộ công cụ COGO.

Khác với app một-file cũ (`topsec-rtk-ios/www/index.html`), bản này:

- Lưu bằng **IndexedDB** thay vì localStorage (không còn giới hạn 5 MB, không nuốt lỗi ghi).
- Mỗi công trình có **hệ tọa độ riêng** (kinh tuyến trục, k0) và hệ tọa độ luôn được ghi kèm khi xuất tệp.
- **MapLibre GL + gom cụm** chịu được 10.000+ điểm (danh sách dùng virtualization).
- Danh sách tỉnh cập nhật theo **Nghị quyết 202/2025/QH15** (34 tỉnh), kinh tuyến trục theo Thông tư 25/2014.
- Xuất **CSV có BOM** (Excel đọc đúng tiếng Việt), **DXF có `$INSUNITS = 6`**, KML, GeoJSON, và **sao lưu JSON**.
- **Trình chiếu point cloud 3D** (Potree 2.x) ngay trong app, không cần cài thêm phần mềm.

## 1. Cài đặt và chạy

Yêu cầu: Node.js 20 trở lên.

```bash
cd web
npm install          # lần đầu
npm run dev          # http://127.0.0.1:5180
```

Lệnh khác:

```bash
npm run build        # tsc --noEmit + vite build → thư mục dist/
npm test             # chạy test (vitest), ~0,4 giây
npm run preview      # xem thử bản build tại http://127.0.0.1:4180
```

`npm test` kiểm tra ba phần dễ sai âm thầm: chuyển đổi VN-2000 ⇄ WGS-84 (`crs`), đọc tệp CSV/TXT/GeoJSON/
bản sao lưu (`importers`), và nội dung tệp xuất ra (`exporters`). Sửa logic ở ba tệp đó thì chạy `npm test`
trước khi bàn giao. Riêng bộ đọc KML cần `DOMParser` của trình duyệt nên không nằm trong bộ test Node.

Muốn mở từ máy khác trong cùng mạng LAN (ví dụ điện thoại), chạy `npm run dev -- --host` rồi truy cập
`http://<IP-máy-tính>:5180`. Cổng được cố định trong `vite.config.ts` (`strictPort: true`).

## 2. Cấu trúc

```
web/
├── index.html
├── src/
│   ├── App.tsx                 # trạng thái, IndexedDB, điều phối hộp thoại
│   ├── main.tsx
│   ├── styles.css
│   ├── components/             # TopBar, Sidebar, MapView, các dialog
│   └── lib/
│       ├── types.ts            # Project, SurveyPoint, CRSConfig
│       ├── provinces.ts        # 34 tỉnh + kinh tuyến trục, múi 6°
│       ├── crs.ts              # proj4, bộ 7 tham số, toGrid/toWgs
│       ├── geo.ts              # nghịch, thuận, giao hội, diện tích
│       ├── db.ts               # IndexedDB: loadAll/putMany/removeMany
│       ├── importers.ts        # CSV/TXT/GeoJSON/KML/backup
│       ├── exporters.ts        # CSV/TXT/DXF/KML/GeoJSON/backup
│       ├── sample.ts           # dữ liệu mẫu (chỉ để thử)
│       ├── format.ts           # toFixed, ngày giờ, tải tệp
│       ├── pointcloud.ts       # đọc Potree 2.x: metadata, hierarchy, Range
│       └── __tests__/          # test vitest: crs, importers, exporters, pointcloud
```

## 3. Quy trình sử dụng

1. **Tạo công trình** – `+ Công trình`, nhập tên, chọn tỉnh/thành. Kinh tuyến trục tự điền; tỉnh sau sáp nhập
   có nhiều khu vực KTT thì chọn đúng khu vực công trình nằm trong.
2. **Đưa điểm vào** – `Nhập dữ liệu` (tệp hoặc dán), `+ Thêm điểm` (gõ X/Y hoặc B/L, hệ còn lại tự tính),
   hoặc đo trên bản đồ bằng nút 📐.
3. **Làm việc trên bản đồ** – bấm cụm để phóng to, bấm điểm để xem X, Y, H, sai số; tick trong danh sách để chọn
   nhiều điểm; thanh trạng thái hiện tọa độ con trỏ theo đúng KTT của công trình. Góc trên trái có **chú thích màu**
   (xanh navy: nhập tệp, cam: đo trên bản đồ, đỏ: GPS điện thoại, xanh ngọc: nhập tay, tím: COGO) kèm số điểm từng loại.
4. **Công cụ** – nghịch, thuận, giao hội góc, giao hội cạnh, diện tích, chuyển đổi B/L ⇄ X/Y. Kết quả lưu được
   thẳng thành điểm.
5. **Xuất dữ liệu** – chọn phạm vi (tất cả / đang chọn), định dạng, số thập phân, rồi tải tệp hoặc sao chép.
6. **Sao lưu** – cuối buổi làm việc xuất **Sao lưu JSON**; tệp này chứa cả hệ tọa độ và nhập lại được.

## 4. Định dạng nhập

| Nguồn | Ghi chú |
| --- | --- |
| CSV / TXT | Tự nhận cột theo tiêu đề (`Ten`, `X`, `Y`, `H`, `Ma`, `B`, `L`…) hoặc theo thứ tự cột. Có/không tiêu đề đều được. Dấu phẩy hay chấm phẩy đều đọc được. |
| GeoJSON | Đọc `Point`/`MultiPoint`, ưu tiên B/L. |
| KML | Đọc `Placemark/Point`. |
| Sao lưu JSON | Khôi phục đầy đủ, kèm hệ tọa độ gốc. |

Trong hộp thoại nhập phải chọn đúng **hệ tọa độ của tệp**: VN-2000 (X, Y) hay WGS-84 (B, L). Nếu chọn sai,
điểm sẽ lệch hàng trăm mét — kiểm tra 6 dòng xem trước trước khi bấm Nhập.

### Lấy dữ liệu từ Excel

1. Trong Excel: `File → Save As → CSV UTF-8 (Comma delimited) (*.csv)`. **Không** dùng “CSV (Comma delimited)”
   bản ANSI — tên điểm tiếng Việt sẽ thành ký tự lạ.
2. Đặt tiêu đề rõ ràng: `Tên điểm`, `Tọa độ X (m)`, `Tọa độ Y (m)`, `Cao độ (m)`, `Mã điểm`. Có đơn vị trong
   ngoặc, có dấu, viết hoa/thường đều nhận.
3. Chấp nhận được: cột `STT` đứng trước, cột `Ghi chú`/`Ngày đo` thừa, dấu phân cách `,` hoặc `;`, số kiểu
   `1.200.039,830` hay `1,200,039.83`, dấu thập phân `,` hay `.`.
4. Tệp `.xlsx` không đọc trực tiếp. Bỏ dòng tiêu đề phụ, bỏ ô gộp (merge) và dán giá trị thay công thức trước khi lưu CSV.
5. Xem 6 dòng đầu trong hộp thoại: nếu X khoảng vài trăm nghìn còn Y khoảng một–hai triệu thì cột đang bị tráo —
   app tự đảo khi nhận ra, nhưng cảnh báo “X/Y ngoài khoảng VN-2000” nghĩa là sai kinh tuyến trục hoặc sai cột, đừng bấm Nhập.

## 5. Trình chiếu point cloud 3D

Nút **🛰 Trình chiếu** trên thanh công cụ mở chế độ xem 3D (nền tối) cho dữ liệu quét LiDAR/drone đã xuất theo
định dạng **Potree 2.x** — đúng bộ tệp công ty đang có (`metadata.oct`, `hierarchy.bin`, `octree.bin`).

Cách mở:

| Cách | Khi nào dùng |
| --- | --- |
| **Chọn thư mục** | Trỏ vào thư mục `..._potree` trên máy. Đọc thẳng từ đĩa, **không copy, không tải lên**. |
| Kéo–thả 3 tệp | Khi chỉ muốn mở một bộ cụ thể (thả cả 3 tệp cùng lúc). |
| **dataIndex.json** | Mở danh mục dự án (nhiều lớp: point cloud, mô hình, ảnh…) rồi chọn lớp cần xem. |
| **Mở URL** | Khi dữ liệu nằm trên máy chủ nội bộ/web. |

Lưu ý khi dùng:

- Tệp rất lớn vẫn xem được: trình duyệt chỉ đọc từng khối theo `Range` (bộ cầu nối trong `src/lib/pointcloud.ts`),
  nên mở bộ 15 GB không cần chờ tải hết. Vẫn cần đủ chỗ đĩa cho chính bộ tệp đó.
- Chế độ **Mở URL** yêu cầu máy chủ trả `Accept-Ranges: bytes`, `Content-Range`, và CORS
  (`Access-Control-Allow-Headers: range`, `Access-Control-Expose-Headers: Content-Range`) nếu khác cổng/tên miền.
  `scripts/serve-pointcloud.mjs` là server thử tối giản đã làm sẵn việc này:
  `node scripts/serve-pointcloud.mjs "D:/du-lieu/..._potree" 8766`.
- **offset**: Potree 2.x lưu toạ độ địa phương, `offset` nằm trong metadata. App đưa `offset = 0` cho thư viện render
  (nếu không, hộp bao và điểm lệch nhau hàng chục km, không khối nào được vẽ) nhưng vẫn hiển thị offset gốc trong panel.
- **Màu điểm**: `RGB` khi metadata có thuộc tính `rgb`; không có thì app tự chuyển sang tô theo **Độ cao**
  (Potree 2.x mặc định bỏ qua kiểu màu, chỉ dùng `rgba` nên dữ liệu không màu sẽ ra đen nếu không xử lý).
- **Ngân sách điểm** (0,5–6 triệu) quyết định số điểm vẽ mỗi khung hình; máy yếu hạ xuống để xoay mượt.
  Dòng “Đang hiện” trong panel cho biết số điểm thực tế đang vẽ.
- Phím `Esc` đóng trình chiếu. Chuột trái xoay, chuột phải dịch, lăn thu phóng; **Đặt lại góc nhìn** quay về hộp bao dữ liệu.
- Chưa hỗ trợ: mesh/CAD (`.b3dm`, `.glb`), ảnh toàn cảnh, `gaussianSplat`. Danh mục `dataIndex.json` vẫn hiện các mục này
  nhưng ở trạng thái mờ, bấm vào sẽ báo chưa hỗ trợ.

## 6. Lưu trữ và sao lưu

- Dữ liệu nằm trong IndexedDB của **chính trình duyệt trên máy này**, không gửi lên máy chủ nào.
- App gọi `navigator.storage.persist()` để xin trình duyệt không tự xóa khi máy hết chỗ; thanh trạng thái hiển thị
  `Đang lưu… / Đã lưu trên máy / Lỗi lưu dữ liệu`.
- Khi có lỗi ghi, một dải đỏ hiện trên cùng với nút **Xuất sao lưu** — đừng bỏ qua, dữ liệu mới có thể chưa vào ổ.
- Xóa dữ liệu trình duyệt (cookie & site data) là **mất sạch**. Hãy sao lưu JSON định kỳ.
- Dùng nhiều máy: mỗi máy một cơ sở dữ liệu riêng; chuyển dữ liệu bằng tệp sao lưu JSON.

## 7. Hệ tọa độ và độ chính xác

- VN-2000: ellipsoid WGS-84, Transverse Mercator, `X0 = 500 000`, `X = Bắc`, `Y = Đông`, múi 3° (`k0 = 0.9999`)
  hoặc múi 6° (`k0 = 0.9996`, kinh tuyến trục 48/49/50).
- Chuyển đổi dùng bộ **7 tham số quốc gia**. Sai số thực tế so với tọa độ chính thức của tỉnh thường dưới mét;
  công trình yêu cầu độ chính xác cao phải hiệu chuẩn theo mốc địa phương hoặc trạm base.
- **h elipsoid ≠ H VN-2000 (Hon Dau)**: chênh lệch geoid hàng mét. Không dùng h elipsoid để tính đào/đắp.
- GPS của trình duyệt chỉ đạt vài mét; app ghi rõ nguồn `GPS điện thoại` và sai số ± để không lẫn với điểm đo RTK.
- Đây **không phải** phần mềm RTK: muốn centimet cần máy thu GNSS + NTRIP, app chỉ quản lý và tính toán trên dữ liệu.

## 8. Sự cố thường gặp

| Hiện tượng | Cách xử lý |
| --- | --- |
| Trang trắng, bản đồ không hiện | Kiểm tra WebGL của trình duyệt (Chrome/Edge bật hardware acceleration). Tab bị ẩn/ngủ cũng làm bản đồ ngừng vẽ cho đến khi hiện lại. |
| Nền bản đồ xám trơn, chỉ có điểm | Ảnh nền không tải được (mất mạng hoặc DNS chặn máy chủ tile). Nền “Bản đồ” dùng CARTO (`basemaps.cartocdn.com`) vì `tile.openstreetmap.org` thường bị chặn ở Việt Nam; thử nền “Vệ tinh” (Esri) hoặc “Trống”. |
| `Port 5180 is already in use` | Đã có dev server khác chạy; tắt nó hoặc sửa `server.port` trong `vite.config.ts`. |
| Mở CSV bằng Excel bị dồn một cột | Tệp xuất đã có BOM và dấu phẩy; nếu vẫn lỗi, kiểm tra Windows đang để dấu phân cách danh sách là `;` — dùng `Data → From Text/CSV`. |
| Nhập tệp ra 0 điểm | Sai hệ tọa độ/cột. Xem cảnh báo trong hộp thoại; kiểm tra tệp có cột X/Y hoặc B/L. |
| Điểm lệch vài trăm mét | Chọn sai kinh tuyến trục hoặc sai hệ (VN-2000 vs WGS-84). Sửa hệ tọa độ công trình rồi nhập lại tệp. |
| Trình chiếu báo “không đọc được metadata” | Thư mục phải chứa đúng `metadata.oct` (hoặc `metadata.json`), `hierarchy.bin`, `octree.bin` của Potree 2.x. Bộ Potree 1.x hoặc tệp `.laz`/`.las` thô chưa hỗ trợ. |
| Trình chiếu mở URL báo lỗi tải | Máy chủ thiếu `Range`/CORS, hoặc chặn `localhost`. Kiểm tra bằng `curl -I` xem có `Accept-Ranges: bytes` và `Access-Control-Allow-Origin`. |
| Trình chiếu giật khi xoay | Hạ **Ngân sách điểm** xuống 1–2 triệu, tắt bớt tab khác; dữ liệu 700 triệu điểm không thể vẽ hết cùng lúc. |
| Báo “Lỗi lưu dữ liệu” | Hết dung lượng hoặc trình duyệt chặn IndexedDB (chế độ riêng tư). Xuất sao lưu ngay, mở bằng cửa sổ thường. |

## 9. Ghi chú phát hành

- Ảnh nền vệ tinh (Esri) và OpenStreetMap dùng cho nội bộ/thử nghiệm; phát hành rộng rãi cần nhà cung cấp có hợp đồng.
- Chưa có đăng nhập, chưa đồng bộ nhiều người. Nếu cần, đó là bước tiếp theo (máy chủ + tài khoản + phân quyền).
